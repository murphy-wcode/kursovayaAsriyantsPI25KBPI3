﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormHistory : Form
    {
        private List<Appointment> _myAppointments = new List<Appointment>();

        public FormHistory()
        {
            InitializeComponent();
            RefreshList();
            UiTheme.Apply(this, () => this.Close());
        }

        private void RefreshList()
        {
            lstHistory.Items.Clear();

            _myAppointments = DataStore.Appointments
                .Where(a => a.OwnerLogin == DataStore.CurrentUser.Login)
                .OrderByDescending(a => a.DateStart)
                .ToList();

            if (_myAppointments.Count == 0)
            {
                lstHistory.Items.Add("У вас пока нет записей.");
                btnCancel.Enabled = false;
                return;
            }

            btnCancel.Enabled = true;

            foreach (var app in _myAppointments)
            {
                string line = $"[{app.Status}] {app.DateStart:dd.MM HH:mm}-{app.DateEnd:HH:mm} | " +
                              $"{app.PetName} | {app.DoctorName} | {app.Price} руб.";
                lstHistory.Items.Add(line);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (_myAppointments.Count == 0 || lstHistory.SelectedIndex < 0)
            {
                MessageBox.Show("Выберите запись из списка для отмены.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedApp = _myAppointments[lstHistory.SelectedIndex];

            if (selectedApp.DateEnd < DateTime.Now)
            {
                MessageBox.Show("Нельзя отменить уже прошедший приём.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string confirmText = selectedApp.Status == "Подтверждена"
                ? "Эта запись уже подтверждена клиникой. Вы уверены, что хотите её отменить и удалить?"
                : "Вы действительно хотите отменить выбранную запись?";

            var result = MessageBox.Show(confirmText, "Подтверждение отмены", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result != DialogResult.Yes) return;

            DataStore.Appointments.Remove(selectedApp);
            DataStore.Save();

            MessageBox.Show("Запись отменена и удалена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshList();
        }
    }
}