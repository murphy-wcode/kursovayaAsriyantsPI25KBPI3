﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace kursovaya20
{
    public class User
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
    }

    public class Pet
    {
        public string Name { get; set; }
        public string Species { get; set; }
        public string Breed { get; set; }
        public string OwnerLogin { get; set; }
    }

    public class Doctor
    {
        public string FullName { get; set; }
        public string Specialization { get; set; }
    }

    public class VetService
    {
        public string Specialization { get; set; }
        public string Name { get; set; }
        public int DurationMinutes { get; set; }
        public decimal Price { get; set; }

        public override string ToString()
        {
            return $"{Name} ({DurationMinutes} мин — {Price} руб.)";
        }
    }

    public class Appointment
    {
        public string OwnerLogin { get; set; }
        public string PetName { get; set; }
        public string DoctorName { get; set; }
        public string ServiceName { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime DateEnd { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }
    }

    public class AppData
    {
        public List<User> Users { get; set; } = new List<User>();
        public List<Pet> Pets { get; set; } = new List<Pet>();
        public List<Appointment> Appointments { get; set; } = new List<Appointment>();
    }

    public static class DataStore
    {
        private static readonly string FilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "vetcare_data.xml");

        public static List<User> Users = new List<User>();
        public static List<Pet> Pets = new List<Pet>();
        public static List<Doctor> Doctors = new List<Doctor>();
        public static List<VetService> Services = new List<VetService>();
        public static List<Appointment> Appointments = new List<Appointment>();

        public static User CurrentUser = null;

        static DataStore()
        {
            // 8 врачей разных специализаций
            Doctors.Add(new Doctor { FullName = "Иванов И.И.", Specialization = "Терапевт" });
            Doctors.Add(new Doctor { FullName = "Петрова А.С.", Specialization = "Хирург" });
            Doctors.Add(new Doctor { FullName = "Сидоров В.В.", Specialization = "Офтальмолог" });
            Doctors.Add(new Doctor { FullName = "Козлова М.Д.", Specialization = "Дерматолог" });
            Doctors.Add(new Doctor { FullName = "Волков А.П.", Specialization = "Стоматолог" });
            Doctors.Add(new Doctor { FullName = "Морозова Е.Н.", Specialization = "Кардиолог" });
            Doctors.Add(new Doctor { FullName = "Лебедев Д.С.", Specialization = "Ортопед" });
            Doctors.Add(new Doctor { FullName = "Новикова О.В.", Specialization = "Ратолог" });

            // Терапевт
            Services.Add(new VetService { Specialization = "Терапевт", Name = "Первичный осмотр", DurationMinutes = 30, Price = 1000m });
            Services.Add(new VetService { Specialization = "Терапевт", Name = "Вакцинация", DurationMinutes = 30, Price = 1500m });
            Services.Add(new VetService { Specialization = "Терапевт", Name = "УЗИ / диагностика", DurationMinutes = 45, Price = 2000m });
            Services.Add(new VetService { Specialization = "Терапевт", Name = "Чипирование", DurationMinutes = 30, Price = 1200m });

            // Хирург
            Services.Add(new VetService { Specialization = "Хирург", Name = "Консультация хирурга", DurationMinutes = 30, Price = 1200m });
            Services.Add(new VetService { Specialization = "Хирург", Name = "Перевязка / снятие швов", DurationMinutes = 30, Price = 800m });
            Services.Add(new VetService { Specialization = "Хирург", Name = "Кастрация / стерилизация", DurationMinutes = 90, Price = 4500m });
            Services.Add(new VetService { Specialization = "Хирург", Name = "Хирургическая операция", DurationMinutes = 120, Price = 6000m });

            // Офтальмолог
            Services.Add(new VetService { Specialization = "Офтальмолог", Name = "Осмотр офтальмолога", DurationMinutes = 30, Price = 1300m });
            Services.Add(new VetService { Specialization = "Офтальмолог", Name = "Измерение глазного давления", DurationMinutes = 30, Price = 1000m });
            Services.Add(new VetService { Specialization = "Офтальмолог", Name = "Промывание слёзного канала", DurationMinutes = 45, Price = 1800m });
            Services.Add(new VetService { Specialization = "Офтальмолог", Name = "Микрохирургия глаза", DurationMinutes = 90, Price = 5500m });

            // Дерматолог
            Services.Add(new VetService { Specialization = "Дерматолог", Name = "Осмотр дерматолога и соскоб", DurationMinutes = 30, Price = 1400m });
            Services.Add(new VetService { Specialization = "Дерматолог", Name = "Лечение отита / чистка ушей", DurationMinutes = 30, Price = 1100m });

            // Стоматолог
            Services.Add(new VetService { Specialization = "Стоматолог", Name = "Ультразвуковая чистка зубов", DurationMinutes = 60, Price = 3500m });
            Services.Add(new VetService { Specialization = "Стоматолог", Name = "Удаление больного зуба", DurationMinutes = 45, Price = 2200m });

            // Кардиолог
            Services.Add(new VetService { Specialization = "Кардиолог", Name = "Приём кардиолога и ЭКГ", DurationMinutes = 45, Price = 2300m });
            Services.Add(new VetService { Specialization = "Кардиолог", Name = "ЭхоКГ (УЗИ сердца)", DurationMinutes = 45, Price = 2800m });

            // Ортопед
            Services.Add(new VetService { Specialization = "Ортопед", Name = "Осмотр ортопеда при хромоте", DurationMinutes = 30, Price = 1500m });
            Services.Add(new VetService { Specialization = "Ортопед", Name = "Наложение гипса / лангеты", DurationMinutes = 60, Price = 3000m });

            // Ратолог
            Services.Add(new VetService { Specialization = "Ратолог", Name = "Осмотр грызуна / птицы", DurationMinutes = 30, Price = 1200m });
            Services.Add(new VetService { Specialization = "Ратолог", Name = "Коррекция резцов и когтей", DurationMinutes = 30, Price = 900m });

            Load();
            EnsureDoctorAccounts();
        }

        private static void EnsureDoctorAccounts()
        {
            var defaultDoctors = new List<User>
            {
                new User { Login = "ivanov", Password = "123456", Role = "staff", FullName = "Иванов И.И.", Email = "ivanov@vetcare.ru" },
                new User { Login = "petrova", Password = "123456", Role = "staff", FullName = "Петрова А.С.", Email = "petrova@vetcare.ru" },
                new User { Login = "sidorov", Password = "123456", Role = "staff", FullName = "Сидоров В.В.", Email = "sidorov@vetcare.ru" },
                new User { Login = "kozlova", Password = "123456", Role = "staff", FullName = "Козлова М.Д.", Email = "kozlova@vetcare.ru" },
                new User { Login = "volkov", Password = "123456", Role = "staff", FullName = "Волков А.П.", Email = "volkov@vetcare.ru" },
                new User { Login = "morozova", Password = "123456", Role = "staff", FullName = "Морозова Е.Н.", Email = "morozova@vetcare.ru" },
                new User { Login = "lebedev", Password = "123456", Role = "staff", FullName = "Лебедев Д.С.", Email = "lebedev@vetcare.ru" },
                new User { Login = "novikova", Password = "123456", Role = "staff", FullName = "Новикова О.В.", Email = "novikova@vetcare.ru" }
            };

            bool added = false;
            foreach (var docUser in defaultDoctors)
            {
                if (!LoginExists(docUser.Login))
                {
                    Users.Add(docUser);
                    added = true;
                }
            }

            if (added)
            {
                Save();
            }
        }

        public static void Save()
        {
            try
            {
                var data = new AppData
                {
                    Users = Users,
                    Pets = Pets,
                    Appointments = Appointments
                };

                var serializer = new XmlSerializer(typeof(AppData));
                using (var writer = new StreamWriter(FilePath))
                {
                    serializer.Serialize(writer, data);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show($"Ошибка сохранения данных: {ex.Message}");
            }
        }

        public static void Load()
        {
            if (!File.Exists(FilePath)) return;

            try
            {
                var serializer = new XmlSerializer(typeof(AppData));
                using (var reader = new StreamReader(FilePath))
                {
                    var data = (AppData)serializer.Deserialize(reader);
                    if (data != null)
                    {
                        Users = data.Users ?? new List<User>();
                        Pets = data.Pets ?? new List<Pet>();
                        Appointments = data.Appointments ?? new List<Appointment>();
                    }
                }
            }
            catch
            {
            }
        }

        public static bool LoginExists(string login)
        {
            return Users.Exists(u => u.Login == login);
        }
    }
}