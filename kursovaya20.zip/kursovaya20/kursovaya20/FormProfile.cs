﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormProfile : Form
    {
        private List<Pet> _myPets = new List<Pet>();
        private Button btnEditPet;
        private Button btnDeletePet;

        public FormProfile()
        {
            InitializeComponent();

            btnEditPet = new Button
            {
                Name = "btnEditPet",
                Text = "Редактировать"
            };
            btnEditPet.Click += btnEditPet_Click;

            btnDeletePet = new Button
            {
                Name = "btnDeletePet",
                Text = "Удалить"
            };
            btnDeletePet.Click += btnDeletePet_Click;

            this.Controls.Add(btnEditPet);
            this.Controls.Add(btnDeletePet);

            LoadData();

            UiTheme.Apply(this, () => this.Close());

            this.Load += (s, e) => CenterProfileLayout();
        }

        private void CenterProfileLayout()
        {
            int centerX = this.ClientSize.Width / 2;

            lblTitle.Top = 48;
            lblTitle.Left = (this.ClientSize.Width - lblTitle.Width) / 2;

            int totalBlockWidth = 510;
            int labelX = centerX - totalBlockWidth / 2;
            int inputX = labelX + 165;
            int inputWidth = 345;

            lblFullName.Location = new Point(labelX, 108);
            txtFullName.Location = new Point(inputX, 105);
            txtFullName.Width = inputWidth;

            lblEmail.Location = new Point(labelX, 155);
            txtEmail.Location = new Point(inputX, 152);
            txtEmail.Width = inputWidth;

            btnSave.Size = new Size(200, 40);
            btnSave.Location = new Point(centerX - btnSave.Width / 2, 198);
            UiTheme.ApplyRoundedCorners(btnSave, 12);

            if (DataStore.CurrentUser.Role == "staff") return;

            lblPets.Location = new Point(labelX, 262);
            lstPets.Location = new Point(inputX, 260);
            lstPets.Width = inputWidth;
            lstPets.Height = 135;

            int btnY = lstPets.Bottom + 14;
            int btnH = 38;

            btnAddPet.Text = "Добавить";
            btnAddPet.Size = new Size(105, btnH);
            btnAddPet.Location = new Point(inputX, btnY);
            btnAddPet.BackColor = UiTheme.BlushPink;
            btnAddPet.ForeColor = UiTheme.TextDark;

            btnEditPet.Size = new Size(125, btnH);
            btnEditPet.Location = new Point(btnAddPet.Right + 10, btnY);

            btnDeletePet.Size = new Size(95, btnH);
            btnDeletePet.Location = new Point(btnEditPet.Right + 10, btnY);

            UiTheme.ApplyRoundedCorners(btnAddPet, 10);
            UiTheme.ApplyRoundedCorners(btnEditPet, 10);
            UiTheme.ApplyRoundedCorners(btnDeletePet, 10);

            this.Invalidate();
        }

        private void LoadData()
        {
            txtFullName.Text = DataStore.CurrentUser.FullName;
            txtEmail.Text = DataStore.CurrentUser.Email;

            if (DataStore.CurrentUser.Role == "staff")
            {
                lblPets.Visible = false;
                lstPets.Visible = false;
                btnAddPet.Visible = false;
                btnEditPet.Visible = false;
                btnDeletePet.Visible = false;
            }
            else
            {
                LoadPets();
            }
        }

        private void LoadPets()
        {
            lstPets.Items.Clear();
            _myPets = DataStore.Pets.Where(p => p.OwnerLogin == DataStore.CurrentUser.Login).ToList();

            foreach (var pet in _myPets)
            {
                lstPets.Items.Add($"{pet.Name} ({pet.Species}, {pet.Breed})");
            }

            bool hasPets = _myPets.Count > 0;
            btnEditPet.Enabled = hasPets;
            btnDeletePet.Enabled = hasPets;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("ФИО не может быть пустым.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataStore.CurrentUser.FullName = fullName;
            DataStore.CurrentUser.Email = email;
            DataStore.Save();

            MessageBox.Show("Данные профиля обновлены.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAddPet_Click(object sender, EventArgs e)
        {
            ShowPetDialog(null);
        }

        private void btnEditPet_Click(object sender, EventArgs e)
        {
            if (lstPets.SelectedIndex < 0 || lstPets.SelectedIndex >= _myPets.Count)
            {
                MessageBox.Show("Выберите питомца из списка для редактирования.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ShowPetDialog(_myPets[lstPets.SelectedIndex]);
        }

        private void btnDeletePet_Click(object sender, EventArgs e)
        {
            if (lstPets.SelectedIndex < 0 || lstPets.SelectedIndex >= _myPets.Count)
            {
                MessageBox.Show("Выберите питомца из списка для удаления.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedPet = _myPets[lstPets.SelectedIndex];

            var activeAppointments = DataStore.Appointments
                .Where(a => a.OwnerLogin == DataStore.CurrentUser.Login &&
                            a.PetName == selectedPet.Name &&
                            a.Status != "Отменена" &&
                            a.DateStart >= DateTime.Now)
                .ToList();

            string message = activeAppointments.Count > 0
                ? $"У питомца «{selectedPet.Name}» есть активные записи на приём ({activeAppointments.Count} шт.).\nПри удалении питомца эти записи также будут отменены. Продолжить?"
                : $"Вы действительно хотите удалить питомца «{selectedPet.Name}» из профиля?";

            var confirm = MessageBox.Show(message, "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            foreach (var app in activeAppointments)
            {
                DataStore.Appointments.Remove(app);
            }

            DataStore.Pets.Remove(selectedPet);
            DataStore.Save();
            LoadPets();

            MessageBox.Show("Питомец удалён.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowPetDialog(Pet existingPet)
        {
            bool isEdit = existingPet != null;

            Form prompt = new Form()
            {
                Width = 400,
                Height = 270,
                Text = isEdit ? "Редактировать питомца" : "Новый питомец"
            };

            Label lblName = new Label() { Left = 25, Top = 28, Text = "Имя питомца:", Width = 125 };
            TextBox txtName = new TextBox() { Left = 160, Top = 25, Width = 195, Text = isEdit ? existingPet.Name : "" };

            Label lblSpecies = new Label() { Left = 25, Top = 73, Text = "Вид (кошка/собака):", Width = 135 };
            TextBox txtSpecies = new TextBox() { Left = 160, Top = 70, Width = 195, Text = isEdit ? existingPet.Species : "" };

            Label lblBreed = new Label() { Left = 25, Top = 118, Text = "Порода:", Width = 125 };
            TextBox txtBreed = new TextBox() { Left = 160, Top = 115, Width = 195, Text = isEdit ? existingPet.Breed : "" };

            Button btnOk = new Button()
            {
                Text = isEdit ? "Сохранить" : "Добавить",
                Left = 135,
                Top = 170,
                Width = 130,
                Height = 40,
                DialogResult = DialogResult.OK
            };
            prompt.AcceptButton = btnOk;

            prompt.Controls.Add(lblName); prompt.Controls.Add(txtName);
            prompt.Controls.Add(lblSpecies); prompt.Controls.Add(txtSpecies);
            prompt.Controls.Add(lblBreed); prompt.Controls.Add(txtBreed);
            prompt.Controls.Add(btnOk);

            UiTheme.Apply(prompt);

            if (prompt.ShowDialog() == DialogResult.OK)
            {
                string petName = txtName.Text.Trim();
                if (string.IsNullOrWhiteSpace(petName))
                {
                    MessageBox.Show("Введите имя питомца.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool alreadyExists = DataStore.Pets.Any(p =>
                    p != existingPet &&
                    p.OwnerLogin == DataStore.CurrentUser.Login &&
                    p.Name.Equals(petName, StringComparison.OrdinalIgnoreCase));

                if (alreadyExists)
                {
                    MessageBox.Show("Питомец с таким именем уже есть в вашем профиле.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string species = string.IsNullOrWhiteSpace(txtSpecies.Text) ? "Не указано" : txtSpecies.Text.Trim();
                string breed = string.IsNullOrWhiteSpace(txtBreed.Text) ? "Не указана" : txtBreed.Text.Trim();

                if (isEdit)
                {
                    if (!existingPet.Name.Equals(petName, StringComparison.Ordinal))
                    {
                        foreach (var app in DataStore.Appointments.Where(a =>
                            a.OwnerLogin == DataStore.CurrentUser.Login && a.PetName == existingPet.Name))
                        {
                            app.PetName = petName;
                        }
                    }

                    existingPet.Name = petName;
                    existingPet.Species = species;
                    existingPet.Breed = breed;
                }
                else
                {
                    DataStore.Pets.Add(new Pet
                    {
                        Name = petName,
                        Species = species,
                        Breed = breed,
                        OwnerLogin = DataStore.CurrentUser.Login
                    });
                }

                DataStore.Save();
                LoadPets();

                MessageBox.Show(isEdit ? "Данные питомца обновлены!" : "Питомец успешно добавлен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}