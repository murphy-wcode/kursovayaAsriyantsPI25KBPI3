﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormRoleSelect : Form
    {
        public FormRoleSelect()
        {
            InitializeComponent();

            UiTheme.Apply(this, () => Application.Exit(), "Выход");

            if (this.Controls["btnThemeBack"] is Button btnExit)
            {
                btnExit.BackColor = UiTheme.WarmSand;
                btnExit.MouseEnter += (s, e) => btnExit.BackColor = UiTheme.PowderRose;
                btnExit.MouseLeave += (s, e) => btnExit.BackColor = UiTheme.WarmSand;
            }

            this.Load += (s, e) => CenterRoleLayout();
        }

        private void CenterRoleLayout()
        {
            int centerX = this.ClientSize.Width / 2;

            lblTitle.Text = "VetCare";
            lblTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblTitle.AutoSize = true;
            lblTitle.Top = 85;
            lblTitle.Left = (this.ClientSize.Width - lblTitle.Width) / 2;

            lblQuestion.Text = "Выберите тип учётной записи для входа в систему";
            lblQuestion.Font = new Font("Segoe UI", 11.5F, FontStyle.Regular);
            lblQuestion.ForeColor = Color.FromArgb(95, 110, 115);
            lblQuestion.AutoSize = true;
            lblQuestion.Top = 142;
            lblQuestion.Left = (this.ClientSize.Width - lblQuestion.Width) / 2;

            int btnWidth = 230;
            int btnHeight = 110;
            int gap = 45;
            int totalWidth = btnWidth * 2 + gap;
            int startX = centerX - totalWidth / 2;

            btnOwner.Size = new Size(btnWidth, btnHeight);
            btnOwner.Location = new Point(startX, 205);

            btnStaff.Size = new Size(btnWidth, btnHeight);
            btnStaff.Location = new Point(startX + btnWidth + gap, 205);

            if (this.Controls["btnThemeBack"] is Button btnExit)
            {
                btnExit.Size = new Size(160, 42);
                btnExit.Location = new Point(centerX - btnExit.Width / 2, 375);
                UiTheme.ApplyRoundedCorners(btnExit, 12);
            }
        }

        private void btnOwner_Click(object sender, EventArgs e)
        {
            var loginForm = new FormLogin("owner");
            loginForm.Show();
            this.Hide();
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            var loginForm = new FormLogin("staff");
            loginForm.Show();
            this.Hide();
        }
    }
}