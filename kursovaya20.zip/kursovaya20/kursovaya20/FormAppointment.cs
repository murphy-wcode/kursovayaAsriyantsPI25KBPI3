﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormAppointment : Form
    {
        private ComboBox cmbTime;
        private ComboBox cmbService;
        private Label lblHeader;

        public FormAppointment()
        {
            InitializeComponent();

            lblHeader = new Label
            {
                Name = "lblTitleHeader",
                Text = "Запись на приём",
                AutoSize = true,
                Top = 55
            };
            this.Controls.Add(lblHeader);

            dtStart.Format = DateTimePickerFormat.Short;
            dtStart.ShowUpDown = false;
            dtStart.MinDate = DateTime.Today;
            dtStart.ValueChanged += (s, e) => RefreshAvailableTimeSlots();

            cmbTime = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            this.Controls.Add(cmbTime);

            dtEnd.Visible = false;

            cmbService = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbService.SelectedIndexChanged += (s, e) =>
            {
                UpdatePrice();
                RefreshAvailableTimeSlots();
            };
            this.Controls.Add(cmbService);

            cmbDoctor.SelectedIndexChanged += (s, e) => LoadServicesForSelectedDoctor();

            // Применяем тему и добавляем кнопку "← Назад"
            UiTheme.Apply(this, () => this.Close());

            // Выравниваем всю анкету строго по центру карточки после финального масштабирования
            this.Load += (s, e) => CenterAppointmentLayout();

            LoadDoctors();
            LoadPets();
            RefreshAvailableTimeSlots();
        }

        private void CenterAppointmentLayout()
        {
            int centerX = this.ClientSize.Width / 2;
            int totalBlockWidth = 460;
            int labelX = centerX - totalBlockWidth / 2;
            int inputX = labelX + 145;
            int inputWidth = 315;

            lblHeader.Left = (this.ClientSize.Width - lblHeader.Width) / 2;

            lblDoctor.Text = "Врач:";
            lblDoctor.Location = new Point(labelX, 125);
            cmbDoctor.Location = new Point(inputX, 122);
            cmbDoctor.Width = inputWidth;

            lblEnd.Text = "Услуга:";
            lblEnd.Location = new Point(labelX, 180);
            cmbService.Location = new Point(inputX, 177);
            cmbService.Width = inputWidth;

            lblPet.Text = "Питомец:";
            lblPet.Location = new Point(labelX, 235);
            cmbPet.Location = new Point(inputX, 232);
            cmbPet.Width = inputWidth;

            lblStart.Text = "Дата и время:";
            lblStart.Location = new Point(labelX, 290);
            dtStart.Location = new Point(inputX, 287);
            dtStart.Width = 190;

            cmbTime.Location = new Point(dtStart.Right + 15, 287);
            cmbTime.Width = 110;

            lblPrice.Top = 352;
            lblPrice.Left = (this.ClientSize.Width - lblPrice.Width) / 2;

            btnBook.Size = new Size(240, 48);
            btnBook.Location = new Point(centerX - btnBook.Width / 2, 405);
        }

        private string GetSelectedDoctorName()
        {
            if (cmbDoctor.SelectedItem == null) return "";
            string doctorString = cmbDoctor.SelectedItem.ToString();
            int bracketIndex = doctorString.IndexOf('(');
            return bracketIndex > 0 ? doctorString.Substring(0, bracketIndex).Trim() : doctorString.Trim();
        }

        private void LoadDoctors()
        {
            cmbDoctor.Items.Clear();
            foreach (var doc in DataStore.Doctors)
            {
                cmbDoctor.Items.Add($"{doc.FullName} ({doc.Specialization})");
            }
            if (cmbDoctor.Items.Count > 0) cmbDoctor.SelectedIndex = 0;
        }

        private void LoadServicesForSelectedDoctor()
        {
            if (cmbDoctor.SelectedItem == null || cmbService == null) return;

            string doctorString = cmbDoctor.SelectedItem.ToString();
            int openBracket = doctorString.IndexOf('(');
            int closeBracket = doctorString.IndexOf(')');

            string specialization = (openBracket >= 0 && closeBracket > openBracket)
                ? doctorString.Substring(openBracket + 1, closeBracket - openBracket - 1).Trim()
                : "";

            cmbService.Items.Clear();
            var filteredServices = DataStore.Services
                .Where(s => s.Specialization.Equals(specialization, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (filteredServices.Count == 0)
            {
                filteredServices = DataStore.Services;
            }

            foreach (var s in filteredServices)
            {
                cmbService.Items.Add(s);
            }

            if (cmbService.Items.Count > 0) cmbService.SelectedIndex = 0;
            UpdatePrice();
            RefreshAvailableTimeSlots();
        }

        private bool IsDoctorAvailable(string doctorName, DateTime start, DateTime end)
        {
            return !DataStore.Appointments.Any(a =>
                a.DoctorName == doctorName &&
                a.Status != "Отменена" &&
                a.DateStart < end && a.DateEnd > start);
        }

        private void RefreshAvailableTimeSlots()
        {
            if (cmbTime == null) return;

            string previouslySelected = cmbTime.SelectedItem?.ToString();
            cmbTime.Items.Clear();

            string doctorName = GetSelectedDoctorName();
            int duration = (cmbService?.SelectedItem is VetService service) ? service.DurationMinutes : 30;
            DateTime selectedDate = dtStart.Value.Date;
            DateTime now = DateTime.Now;

            for (int hour = 9; hour <= 20; hour++)
            {
                for (int minute = 0; minute < 60; minute += 30)
                {
                    DateTime slotStart = selectedDate.AddHours(hour).AddMinutes(minute);
                    DateTime slotEnd = slotStart.AddMinutes(duration);

                    if (slotStart <= now) continue;
                    if (slotEnd.Date != selectedDate || slotEnd.Hour > 21 || (slotEnd.Hour == 21 && slotEnd.Minute > 0)) continue;

                    if (IsDoctorAvailable(doctorName, slotStart, slotEnd))
                    {
                        cmbTime.Items.Add(slotStart.ToString("HH:mm"));
                    }
                }
            }

            if (cmbTime.Items.Count > 0)
            {
                cmbTime.Enabled = true;
                btnBook.Enabled = true;

                if (previouslySelected != null && cmbTime.Items.Contains(previouslySelected))
                {
                    cmbTime.SelectedItem = previouslySelected;
                }
                else
                {
                    cmbTime.SelectedIndex = 0;
                }
            }
            else
            {
                cmbTime.Items.Add("Нет мест");
                cmbTime.SelectedIndex = 0;
                cmbTime.Enabled = false;
                btnBook.Enabled = false;
            }
        }

        private void LoadPets()
        {
            cmbPet.Items.Clear();
            var myPets = DataStore.Pets.Where(p => p.OwnerLogin == DataStore.CurrentUser.Login).ToList();

            foreach (var pet in myPets)
            {
                cmbPet.Items.Add(pet.Name);
            }

            if (cmbPet.Items.Count > 0)
            {
                cmbPet.SelectedIndex = 0;
            }
            else
            {
                var result = MessageBox.Show(
                    "У вас пока нет добавленных питомцев. Хотите открыть профиль и добавить питомца прямо сейчас?",
                    "Нет питомцев",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    using (var profileForm = new FormProfile())
                    {
                        profileForm.ShowDialog();
                    }

                    myPets = DataStore.Pets.Where(p => p.OwnerLogin == DataStore.CurrentUser.Login).ToList();
                    foreach (var pet in myPets)
                    {
                        cmbPet.Items.Add(pet.Name);
                    }
                    if (cmbPet.Items.Count > 0) cmbPet.SelectedIndex = 0;
                }
            }
        }

        private void UpdatePrice()
        {
            if (cmbService?.SelectedItem is VetService service)
            {
                lblPrice.Text = $"Стоимость: {service.Price} руб.  •  Длительность: {service.DurationMinutes} мин";
                lblPrice.Left = (this.ClientSize.Width - lblPrice.Width) / 2;
            }
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            if (cmbPet.SelectedItem == null)
            {
                MessageBox.Show("Выберите питомца.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbDoctor.SelectedItem == null || !cmbTime.Enabled || cmbTime.SelectedItem == null)
            {
                MessageBox.Show("На выбранную дату нет свободного времени. Выберите другой день или врача.", "Нет мест", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var service = cmbService.SelectedItem as VetService;
            if (service == null) return;

            TimeSpan time = TimeSpan.Parse(cmbTime.SelectedItem.ToString());
            DateTime start = dtStart.Value.Date.Add(time);
            DateTime end = start.AddMinutes(service.DurationMinutes);
            string doctorName = GetSelectedDoctorName();

            if (!IsDoctorAvailable(doctorName, start, end))
            {
                MessageBox.Show($"Это время у врача {doctorName} только что заняли. Список свободных окон обновлён.", "Накладка времени", MessageBoxButtons.OK, MessageBoxIcon.Error);
                RefreshAvailableTimeSlots();
                return;
            }

            DataStore.Appointments.Add(new Appointment
            {
                OwnerLogin = DataStore.CurrentUser.Login,
                PetName = cmbPet.SelectedItem.ToString(),
                DoctorName = doctorName,
                ServiceName = service.Name,
                DateStart = start,
                DateEnd = end,
                Price = service.Price,
                Status = "Запланирована"
            });

            DataStore.Save();

            MessageBox.Show(
                $"Запись создана!\n" +
                $"Услуга: {service.Name}\n" +
                $"Время: {start:dd.MM.yyyy HH:mm} – {end:HH:mm}\n" +
                $"Стоимость: {service.Price} руб.\n" +
                $"Врач: {doctorName}\n" +
                $"Ожидайте подтверждения.",
                "Успех",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            this.Close();
        }

        private void lblStart_VisibleChanged(object sender, EventArgs e)
        {
            UpdatePrice();
        }
    }
}