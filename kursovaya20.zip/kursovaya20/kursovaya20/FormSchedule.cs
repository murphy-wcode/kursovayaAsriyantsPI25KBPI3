﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormSchedule : Form
    {
        private List<Appointment> _visibleAppointments = new List<Appointment>();
        private Label lblHeader;

        public FormSchedule()
        {
            InitializeComponent();

            foreach (Control c in this.Controls)
            {
                if (c is Label) c.Visible = false;
            }

            lblHeader = new Label
            {
                Name = "lblTitleHeader",
                Text = $"Расписание: {DataStore.CurrentUser.FullName}",
                AutoSize = true,
                Top = 52
            };
            this.Controls.Add(lblHeader);

            UiTheme.Apply(this, () => this.Close());

            this.Load += (s, e) => CenterScheduleLayout();

            RefreshList();
        }

        private void CenterScheduleLayout()
        {
            int centerX = this.ClientSize.Width / 2;

            lblHeader.Left = (this.ClientSize.Width - lblHeader.Width) / 2;

            lstAll.Width = this.ClientSize.Width - 140;
            lstAll.Height = 250;
            lstAll.Location = new Point(70, 118);
            lstAll.HorizontalScrollbar = true;

            int btnWidth = 210;
            int btnHeight = 46;
            int gap = 40;
            int totalButtonsWidth = btnWidth * 2 + gap;
            int startX = centerX - totalButtonsWidth / 2;

            btnConfirm.Size = new Size(btnWidth, btnHeight);
            btnConfirm.Location = new Point(startX, 405);

            btnReject.Size = new Size(btnWidth, btnHeight);
            btnReject.Location = new Point(startX + btnWidth + gap, 405);

            this.Invalidate();
        }

        private void RefreshList()
        {
            lstAll.Items.Clear();

            _visibleAppointments = DataStore.Appointments
                .Where(a => a.DoctorName == DataStore.CurrentUser.FullName)
                .OrderBy(a => a.DateStart)
                .ToList();

            if (_visibleAppointments.Count == 0)
            {
                lstAll.Items.Add("У вас пока нет записей на приём.");
                btnConfirm.Enabled = false;
                btnReject.Enabled = false;
                return;
            }

            btnConfirm.Enabled = true;
            btnReject.Enabled = true;

            foreach (var app in _visibleAppointments)
            {
                string serviceInfo = string.IsNullOrEmpty(app.ServiceName) ? "" : $" | {app.ServiceName}";
                string line = $"[{app.Status}] {app.DateStart:dd.MM HH:mm}–{app.DateEnd:HH:mm} | Питомец: {app.PetName} (Владелец: {app.OwnerLogin}){serviceInfo}";
                lstAll.Items.Add(line);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (_visibleAppointments.Count == 0 || lstAll.SelectedIndex < 0)
            {
                MessageBox.Show("Выберите запись из списка.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedApp = _visibleAppointments[lstAll.SelectedIndex];

            if (selectedApp.Status == "Отменена")
            {
                MessageBox.Show("Нельзя подтвердить отмененную запись.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            selectedApp.Status = "Подтверждена";
            DataStore.Save();

            MessageBox.Show("Запись подтверждена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshList();
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            if (_visibleAppointments.Count == 0 || lstAll.SelectedIndex < 0)
            {
                MessageBox.Show("Выберите запись из списка.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedApp = _visibleAppointments[lstAll.SelectedIndex];

            selectedApp.Status = "Отменена";
            DataStore.Save();

            MessageBox.Show("Запись отклонена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshList();
        }
    }
}