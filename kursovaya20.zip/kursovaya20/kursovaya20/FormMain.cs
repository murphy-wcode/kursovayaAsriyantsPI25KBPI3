﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormMain : Form
    {
        private string _role;
        private bool _isLoggingOut = false;

        public FormMain(string role)
        {
            InitializeComponent();
            _role = role;

            lblWelcome.Text = $"Добро пожаловать, {DataStore.CurrentUser.FullName}!";

            UiTheme.Apply(this, () =>
            {
                _isLoggingOut = true;
                DataStore.CurrentUser = null;
                var roleForm = new FormRoleSelect();
                roleForm.Show();
                this.Close();
            }, "← Выйти");

            this.Load += (s, e) => CenterMenuLayout();

            this.FormClosed += (s, e) =>
            {
                if (!_isLoggingOut)
                {
                    Application.Exit();
                }
            };
        }

        private void CenterMenuLayout()
        {
            int centerX = this.ClientSize.Width / 2;
            int btnWidth = 260;
            int btnHeight = 50;

            lblWelcome.Top = 105;
            lblWelcome.Left = (this.ClientSize.Width - lblWelcome.Width) / 2;

            btnProfile.Size = new Size(btnWidth, btnHeight);
            btnProfile.Location = new Point(centerX - btnWidth / 2, 185);

            if (_role == "staff")
            {
                btnSchedule.Visible = true;
                btnAppointment.Visible = false;
                btnHistory.Visible = false;

                btnSchedule.Size = new Size(btnWidth, btnHeight);
                btnSchedule.Location = new Point(centerX - btnWidth / 2, 255);
            }
            else
            {
                btnSchedule.Visible = false;
                btnAppointment.Visible = true;
                btnHistory.Visible = true;

                btnAppointment.Size = new Size(btnWidth, btnHeight);
                btnAppointment.Location = new Point(centerX - btnWidth / 2, 255);

                btnHistory.Size = new Size(btnWidth, btnHeight);
                btnHistory.Location = new Point(centerX - btnWidth / 2, 325);
            }
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            var form = new FormProfile();
            form.ShowDialog();
            lblWelcome.Text = $"Добро пожаловать, {DataStore.CurrentUser.FullName}!";
            lblWelcome.Left = (this.ClientSize.Width - lblWelcome.Width) / 2;
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            var form = new FormAppointment();
            form.ShowDialog();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            var form = new FormHistory();
            form.ShowDialog();
        }

        private void btnSchedule_Click(object sender, EventArgs e)
        {
            var form = new FormSchedule();
            form.ShowDialog();
        }
    }
}