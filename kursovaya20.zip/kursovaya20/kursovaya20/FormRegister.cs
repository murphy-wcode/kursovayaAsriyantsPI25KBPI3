﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursovaya20
{
    public partial class FormRegister : Form
    {
        private string _role;

        public FormRegister(string role)
        {
            InitializeComponent();
            _role = role;
            txtPassword.UseSystemPasswordChar = true;

            if (_role == "owner") lblTitle.Text = "Регистрация владельца";
            else lblTitle.Text = "Регистрация сотрудника";
            UiTheme.Apply(this, () => this.Close());
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;
            string fullName = txtFullName.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Пожалуйста, заполните логин, пароль и ФИО.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (DataStore.LoginExists(login))
            {
                MessageBox.Show("Этот логин уже занят. Придумайте другой.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            User newUser = new User
            {
                Login = login,
                Password = password,
                Role = _role,
                FullName = fullName,
                Email = email
            };

            DataStore.Users.Add(newUser);
            DataStore.Save();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}