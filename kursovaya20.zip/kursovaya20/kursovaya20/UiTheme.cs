﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace kursovaya20
{
    public static class UiTheme
    {
        public static readonly Color SeaTeal = ColorTranslator.FromHtml("#72a8a8");
        public static readonly Color DustyBlue = ColorTranslator.FromHtml("#98b4b7");
        public static readonly Color BlushPink = ColorTranslator.FromHtml("#f3c9cb");
        public static readonly Color PowderRose = ColorTranslator.FromHtml("#eebdb6");
        public static readonly Color WarmSand = ColorTranslator.FromHtml("#eac09a");

        public static readonly Color WindowBg = Color.FromArgb(238, 223, 224);
        public static readonly Color CardBg = Color.FromArgb(252, 249, 249);
        public static readonly Color FieldBg = Color.White;
        public static readonly Color TextDark = Color.FromArgb(45, 55, 60);
        public static readonly Color BorderColor = ColorTranslator.FromHtml("#98b4b7");

        public static void Apply(Form form, Action onBack = null, string backText = "← Назад")
        {
            if (form.ClientSize.Width >= 700)
            {
                form.ClientSize = new Size(900, 540);
            }

            form.BackColor = WindowBg;
            form.ForeColor = TextDark;
            form.Font = new Font("Segoe UI", 10.5F, FontStyle.Regular);
            form.StartPosition = FormStartPosition.CenterScreen;
            form.FormBorderStyle = FormBorderStyle.FixedSingle;
            form.MaximizeBox = false;

            form.Paint -= Form_PaintCardAndBorders;
            form.Paint += Form_PaintCardAndBorders;

            if (onBack != null && form.Controls["btnThemeBack"] == null)
            {
                Button btnBack = new Button
                {
                    Name = "btnThemeBack",
                    Text = backText,
                    Size = new Size(105, 34),
                    Location = new Point(60, 42),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = BlushPink,
                    ForeColor = TextDark,
                    Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                    Cursor = Cursors.Hand
                };
                btnBack.FlatAppearance.BorderSize = 0;
                ApplyRoundedCorners(btnBack, 10);
                AttachHover(btnBack, BlushPink, PowderRose);
                btnBack.Click += (s, e) => onBack();
                form.Controls.Add(btnBack);
                btnBack.BringToFront();
            }

            StyleControls(form, form.Controls);

            // Повторно выравниваем заголовки после окончательного масштабирования окна
            form.Load -= Form_CenterTitlesOnLoad;
            form.Load += Form_CenterTitlesOnLoad;
        }

        private static void Form_CenterTitlesOnLoad(object sender, EventArgs e)
        {
            if (!(sender is Form form)) return;
            foreach (Control ctrl in form.Controls)
            {
                if (ctrl is Label lbl && (lbl.Name.Contains("Title") || lbl.Name.Contains("Welcome") || lbl.Name.Contains("Price")))
                {
                    lbl.Left = (form.ClientSize.Width - lbl.Width) / 2;
                }
            }
        }

        private static void Form_PaintCardAndBorders(object sender, PaintEventArgs e)
        {
            if (!(sender is Form form)) return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            if (form.ClientSize.Width >= 700)
            {
                Rectangle cardRect = new Rectangle(40, 25, form.ClientSize.Width - 80, form.ClientSize.Height - 50);
                using (GraphicsPath path = CreateRoundedPath(cardRect, 18))
                {
                    using (SolidBrush brush = new SolidBrush(CardBg))
                    {
                        e.Graphics.FillPath(brush, path);
                    }
                    using (Pen pen = new Pen(BlushPink, 1.5f))
                    {
                        e.Graphics.DrawPath(pen, path);
                    }
                }
            }

            DrawBordersRecursive(e.Graphics, form.Controls);
        }

        private static void DrawBordersRecursive(Graphics g, Control.ControlCollection controls)
        {
            foreach (Control ctrl in controls)
            {
                if (!ctrl.Visible) continue;

                if (ctrl is TextBox || ctrl is ComboBox || ctrl is ListBox || ctrl is DateTimePicker)
                {
                    Rectangle r = new Rectangle(ctrl.Left - 2, ctrl.Top - 2, ctrl.Width + 3, ctrl.Height + 3);
                    using (Pen pen = new Pen(BorderColor, 1.5f))
                    {
                        g.DrawRectangle(pen, r);
                    }
                }

                if (ctrl.HasChildren)
                {
                    DrawBordersRecursive(g, ctrl.Controls);
                }
            }
        }

        private static void StyleControls(Form form, Control.ControlCollection controls)
        {
            foreach (Control ctrl in controls)
            {
                if (ctrl is Button btn)
                {
                    if (btn.Name != "btnThemeBack")
                        StyleButton(btn);
                }
                else if (ctrl is Label lbl)
                {
                    if (lbl.Name.Contains("Title") || lbl.Name.Contains("Welcome"))
                    {
                        lbl.Font = new Font("Segoe UI", 17F, FontStyle.Bold);
                        lbl.ForeColor = SeaTeal;
                        lbl.BackColor = Color.Transparent;
                        lbl.AutoSize = true;
                        lbl.Left = (form.ClientSize.Width - lbl.Width) / 2;
                    }
                    else if (lbl.Name.Contains("Price"))
                    {
                        lbl.Font = new Font("Segoe UI", 11.5F, FontStyle.Bold);
                        lbl.ForeColor = SeaTeal;
                        lbl.BackColor = Color.Transparent;
                        lbl.AutoSize = true;
                        lbl.Left = (form.ClientSize.Width - lbl.Width) / 2;
                    }
                    else
                    {
                        lbl.Font = new Font("Segoe UI", 10.5F, FontStyle.Regular);
                        lbl.ForeColor = TextDark;
                        lbl.BackColor = Color.Transparent;
                    }
                }
                else if (ctrl is TextBox txt)
                {
                    txt.BackColor = FieldBg;
                    txt.ForeColor = TextDark;
                    txt.BorderStyle = BorderStyle.None;
                    txt.Font = new Font("Segoe UI", 11F, FontStyle.Regular);
                }
                else if (ctrl is ComboBox cmb)
                {
                    cmb.BackColor = FieldBg;
                    cmb.ForeColor = TextDark;
                    cmb.FlatStyle = FlatStyle.Flat;
                    cmb.Font = new Font("Segoe UI", 10.5F, FontStyle.Regular);
                }
                else if (ctrl is ListBox lst)
                {
                    lst.BackColor = FieldBg;
                    lst.ForeColor = TextDark;
                    lst.BorderStyle = BorderStyle.None;
                    lst.Font = new Font("Segoe UI", 10.5F, FontStyle.Regular);
                    lst.ItemHeight = 26;
                }

                if (ctrl.HasChildren)
                {
                    StyleControls(form, ctrl.Controls);
                }
            }
        }

        private static void StyleButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;
            btn.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);

            ApplyRoundedCorners(btn, 12);
            btn.Resize += (s, e) => ApplyRoundedCorners(btn, 12);

            string text = btn.Text.ToLower();

            if (text.Contains("отмен") || text.Contains("отклон") || text.Contains("удал"))
            {
                btn.BackColor = WarmSand;
                btn.ForeColor = TextDark;
                AttachHover(btn, WarmSand, PowderRose);
            }
            else if (text.Contains("регистрац") || text.Contains("профил") || text.Contains("истор"))
            {
                btn.BackColor = BlushPink;
                btn.ForeColor = TextDark;
                AttachHover(btn, BlushPink, PowderRose);
            }
            else
            {
                btn.BackColor = SeaTeal;
                btn.ForeColor = Color.White;
                AttachHover(btn, SeaTeal, DustyBlue);
            }
        }

        private static void AttachHover(Button btn, Color normal, Color hover)
        {
            btn.MouseEnter += (s, e) => btn.BackColor = hover;
            btn.MouseLeave += (s, e) => btn.BackColor = normal;
        }

        private static GraphicsPath CreateRoundedPath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static void ApplyRoundedCorners(Control control, int radius)
        {
            if (control.Width <= 0 || control.Height <= 0) return;
            control.Region = new Region(CreateRoundedPath(new Rectangle(0, 0, control.Width, control.Height), radius));
        }
    }
}